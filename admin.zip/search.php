<?php include"includes/header.php"; ?>


<?php include"includes/nav.php"; ?>







        <!-- Page header with logo and tagline-->
        <header class="py-5 bg-light border-bottom mb-4">
            <div class="container">
                <div class="text-center my-5">
                   <p class="lead mb-0">Welcome to Our Project:</p>
                     <h1 class="fw-bolder">Online Platform and Project Management Software for Business Team</h1>
                </div>
            </div>
        </header>


        <!-- Page content-->
        <div class="container">
            <div class="row">
                <!-- Blog entries-->
                <div class="col-lg-8">


\\ show the search rusult

<?php 

       if(isset($_POST['search'])){
                if($_POST['search'] == ""){
                       $session->message("the Search field should not be empty");
                        redirect("index.php");

                }


                $posts= Posts::search_count($_POST['search']);

                     if($posts == 0){

                        $session->message("No Result");
                        redirect("index.php");


                     }else{

                    $posts= Posts::search_by_tags($_POST['search']);

                
        ?>
// show the post who search on it

<?php  foreach ($posts as $post) :  ?>
                    <!-- Featured blog post-->
                    <div class="card mb-4">
                        <a href="#!"><img class="card-img-top" src="admin/assets/img/posts/<?php echo$post->post_image; ?>" alt="..." /></a>
                        <div class="card-body">
                            <div class="small text-muted"><?php echo $post->assigh_date; ?></div>
                            <h2 class="card-title"><?php echo $post->post_title; ?></h2>
                            <p class="card-text"><?php echo $post->post_content; ?></p>
                            <a class="btn btn-primary" href="index.php">HomePage →</a>
                        </div>
                    </div>

        <?php endforeach; ?>
<?php } } ?>

   </div>



             



                    <!-- Side widget-->

                </div>
            </div>
        </div>



        <!-- Footer-->
<?php include"includes/footer.php"; ?>

   


   