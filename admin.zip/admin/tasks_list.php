
<?php 


// Overall, this script efficiently presents 
//a list of tasks associated with a specific user in a user-friendly table format,
// allowing users to quickly access task details and navigate to view more information about each task.






$project_hr= Project_hr::find_all_by_user_id("180");


 ?>

  <div class="row">
              <div class="col-12 col-sm-12 col-lg-6">
                <div class="card">
                  <div class="card-header">
                    <h4>Tasks list</h4>
                  </div>
                  <div class="card-body">
                        <?php $i=1 ?>

                        
                      <form action="" method="post">
                      <table class="table table-striped">

                        <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>Task Name</th>
                        <th>Status</th>
                        <th>Due Date</th>
                        <th>Link</th>
                        </tr>
                              <?php   foreach ($project_hr as $project) : ?>
                        <tr>
                        <td><?php echo $i."-";$i+=1; ?></td>

                       <td><?php echo $project->id;  ?></td>
                       <td><?php echo $project->task_name; ?></td>
                       <td><?php echo $project->status; ?></td>
                       <td><?php echo $project->due_date; ?></td>
                      
       <td> <a href="tasks.php?id=<?php echo $project->project_id; ?>" class="btn btn-primary">View</a></td>

                        </tr>
                        <?php endforeach; ?>

                      </table>
                    </form>
                   
                  </div>
                </div>
              </div>

         </div>
      


