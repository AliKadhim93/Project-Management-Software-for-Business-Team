

<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">





            <div class="row">
              <div class="col-12">
                <div class="card mb-0">
                  <div class="card-body">
                    <ul class="nav nav-pills">
                      <li class="nav-item">
                        <a class="nav-link active" href="posts.php">All <span class="badge badge-white"><?php echo Posts::count_all(); ?></span></a>
                      </li>


                      <li class="nav-item">
                        <a class="nav-link" href="posts_filter.php?by=Publish">Publish <span class="badge badge-primary"> <?php echo Posts::post_count_by("Publish"); ?></span></a>
                      </li>
                      
                      <li class="nav-item">
                        <a class="nav-link" href="posts_filter.php?by=Draft">Draft <span class="badge badge-primary"> <?php echo Posts::post_count_by("Draft"); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="posts_filter.php?by=Pending">Pending <span class="badge badge-primary"><?php echo Posts::post_count_by("Pending"); ?></span></a>
                      </li>
                      
                    </ul>
                  </div>
                </div>
              </div>
            </div>



            <div class="row mt-4">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>All Posts</h4>
                  </div>
                  <div class="card-body">
// viwe all post

<?php   $posts= Posts::find_all(); ?>
                  
 <a  href="add_post.php" button type="button" class="btn btn-primary" > Add New Post</button> </a>



                    <div class="clearfix mb-3"></div>
                    <div class="table-responsive">
                      <table class="table table-striped">
                        <tr>
                          <th>Post ID</th>
                          <th>Author</th>
                          <th>Title</th>
                          <th>Category</th>
                          <th>Post Image</th>
                          <th>Created At</th>
                          <th>Views</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>

<?php foreach ($posts as $post) : ?>
                        <tr>


                          <td><?php echo $post->id; ?></td>
                        

<td>

                   <?php $id_user =$post->post_author_id; ?>
                     <?php $user = User::find_by_id($id_user); ?>
<a href="#">
<img alt="image" src="assets/img/users/<?php echo $user->img; ?>" class="rounded-circle" width="35"
  data-toggle="title" title="">
<span class="d-inline-block ml-1"><?php echo $user->username;?></span>
</a>
</td>




                          <td> <a href="../posts.php?id=<?php echo $post->id; ?>"><?php echo $post->post_title; ?></a> </td>






        <?php  $department = Department::find_by_id($post->post_department_id); ?>

            <td><?php echo $department->title; ?></td>

<td>  <img width="100"  src="assets/img/posts/<?php  echo $post->post_image; ?>"  alt="image">  </td>
                       

                          <td><?php echo $post->assigh_date; ?></td>
                          <td><?php echo $post->views; ?></td>



<td>
<?php 
$post_status= $post->post_status;
if($post_status == "Publish"){
echo "<div class='badge badge-primary'>Publish</div>";
}
elseif ($post_status == "Pending") {
echo "<div class='badge badge-warning'>Pending</div>";
}else{
echo "<div class='badge badge-danger'>Draft</div>";
}
?>
</td>

                              
                      

                         
                  <td>
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_post.php?id=<?php echo $post->id;  ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_post.php?id=<?php echo $post->id;  ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>



                        </tr>


 <?php endforeach; ?>





                      </table>
                    </div>



                  </div>
                </div>
              </div>
            </div>





      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
