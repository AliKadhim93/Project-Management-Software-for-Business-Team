
<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>



<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>



    

<?php $activities = Activity::find_all(); ?>


  <!-- Main Content -->
      <div class="main-content">
        <section class="section">



  <div class="section-body">
            <div class="row mt-4">
              <div class="col-12">
                <div class="card mb-0">
                  <div class="card-body">
                    <ul class="nav nav-pills">
                      <li class="nav-item">
                        <a class="nav-link active" href="system_activities.php">All <span class="badge badge-white"> <?php echo Activity::count_by_action(""); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="filter_activity.php?by=create" >Create <span class="badge badge-primary"> <?php echo Activity::count_by_action("create"); ?> </span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link"href="filter_activity.php?by=delete" >Delete <span class="badge badge-primary"> <?php echo Activity::count_by_action("delete"); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="filter_activity.php?by=update" >Update <span class="badge badge-primary"><?php echo Activity::count_by_action("update"); ?></span></a>
                      </li>
                 </ul>
                  </div>
                </div>
              </div>
            </div>


//google chart to show the activity in grafic


          <div class="row mt-4">
            <div class="col-4">
              <div class="card">

   <script type="text/javascript">
      google.charts.load("current", {packages:["corechart"]});
      google.charts.setOnLoadCallback(drawChart);
      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Update',     <?php echo Activity::count_by_action("update"); ?>],
          ['Delete',      <?php echo Activity::count_by_action("delete"); ?>],
          ['Create',    <?php echo Activity::count_by_action("create"); ?>]
        ]);

        var options = {
          title: 'System Activities',
          is3D: true,
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart_3d'));
        chart.draw(data, options);
      }
    </script>


  <div id="piechart_3d" style="width: 900px; height: 500px;"></div>

            </div>
              </div>
            </div>






          <div class="row mt-4">
            <div class="col-12">
              <div class="card">
                <div class="card-header">
                  <h4>Activities</h4>
                  <div class="card-header-form">
                    <form>
                      <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search">
                        <div class="input-group-btn">
                          <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div class="card-body p-0">
                  <div class="table-responsive">
                    <table class="table table-striped">
                      <tr>

                        <th>#</th>
                        <th>ID</th>
                        <th>Person Responsible</th>
                        <th>Actions Details</th>
                        <th>Assigh Date</th>
                        <th>Action</th>
                      </tr>

                      <tr>

                       
                          <?php $i=1 ?>
      <?php   foreach ($activities as $activity) : ?>



                        <td><?php echo $i."-"; $i+=1; ?></td>
                        <td><?php echo $activity->id; ?></td>

<td>

                   <?php $id_user =$activity->created_by; ?>
                     <?php $user = User::find_by_id($id_user); ?>
<a href="#">
<img alt="image" src="assets/img/users/<?php echo $user->img; ?>" class="rounded-circle" width="35"
  data-toggle="title" title="">
<span class="d-inline-block ml-1"><?php echo $user->username;?></span>
</a>
</td>

                       

                                    
                 
                                    <td><?php echo $activity->details; ?></td>

                        <td><?php echo $activity->date; ?></td>

 <td>

<?php 


if($activity->action_name == "post"){
 echo" <a href='posts.php?id=$activity->action_id' class='btn btn-outline-primary'>Link</a>";
}elseif ($activity->action_name == "project") {
   echo" <a href='projects.php?id=$activity->action_id' class='btn btn-outline-primary'>Link</a>";
}elseif ($activity->action_name == "user") {
   echo" <a href='users.php?id=$activity->action_id' class='btn btn-outline-primary'>Link</a>";
}else{
  echo" <a href='departments.php?id=$activity->action_id' class='btn btn-outline-primary'>Link</a>";
}






 ?>

                        </td>
                    

                       

                      </tr>
                       <?php endforeach; ?>






                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>




   
      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
