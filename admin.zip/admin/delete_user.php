<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>




<?php 



// delte user and add activity for delet user
$activity = new Activity();

if(empty($_GET['id'])){
        header("Location: all_users.php");
}



$user= User::find_by_id($_GET['id']);

if($user){




$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Delete User ID: ".  $user->id . " ";
$activity->action_id =  $_GET['id'];
$activity->action_name = "Delete";

$activity->save();







    $user->delete();
        redirect("all_users.php");    
          $session->message("User ID :".$_GET['id']." has been Deleted successfully");
}else{
        redirect("all_users.php");    

}




 ?>
























<?php include"admin_includes/admin_footer.php"; ?>






