

//it resbansabel for activie to inter dashbord
  <div class="row">
              <div class="col-12 col-sm-12 col-lg-6">
                <div class="card">
                  <div class="card-header">
                    <h4>Request Access to Dashboard System</h4>
                  </div>
                  <div class="card-body">
                        <?php $i=1 ?>

                         <?php $Users= User::final_all_request("disable"); ?>
                      <form action="" method="post">
                      <table class="table table-striped">

                        <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Aceess</th>
                        <th>Time Request</th>
                        <th>Accept</th>
                         
                        </tr>
                              <?php   foreach ($Users as $User) : ?>
                        <tr>
                        <td><?php echo $i."-";$i+=1; ?></td>

                           <td><?php echo $User->id; ?></td>
                          <td><?php echo $User->username; ?></td>
                          <td><div class='badge badge-danger'><?php echo $User->access; ?></div> </td>
                         <td><?php echo $User->created_at; ?></td>

 <td>

     <a href="request_user.php?id=<?php echo $User->id; ?>" class="btn btn-outline-success">Accept</a> 
  
                  
</td>
                        </tr>
                        <?php endforeach; ?>

                      </table>
                    </form>
                   
                  </div>
                </div>
              </div>

         </div>
      
