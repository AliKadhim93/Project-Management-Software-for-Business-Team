


//Overall, this script handles the creation of a new project and logs the action using an activity log.
// It provides a user-friendly interface for entering project details through a modal form.








<?php  

$project = new Project();
$activity = new Activity();
if(isset($_POST['create_project'])){


if($project){
 $project->project_name = $_POST['project_name'];
 $project->project_status = $_POST['project_status'];
 $project->assigh_date = date('d-m-y');
 $project->due_date = $_POST['due_date'];
 $project->priority = $_POST['priority'];
 $project->departments_id = $_POST['departments_id'];
 $project->created_by = $_SESSION['user_id'];

if(empty($_FILES['project_image'])){




  
$project->save();





$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Add New Project ID: ".  $project->id . " ";
$activity->action_id =  $project->id;
$activity->action_name = "Create";

$activity->save();




redirect("projects.php");
 $session->message("Project has been added successfully");
}

}}


 ?>






      <!-- basic modal -->
        <div class="modal fade" id="add_project_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add New Project</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>



              <div class="modal-body">

            <div class="card-body">

              <form action=""  method="post" enctype="multipart/form-data" >
   
                <div class="form-group">
                      <label>Project Name</label>
                      <input name="project_name" type="text" class="form-control">
                    </div>

 
                 

            <div class="form-group">
                      <label>Status</label>
                      <select class="form-control" name="project_status"  >
                     <option>In Progress</option>
                     <option>Complate</option>
                     </select>
                    </div>

             <div class="form-group">
               <label>Departments</label>
             <select class="form-control" name="departments_id"  >
                <?php $Departments= Department::find_all();
            foreach ($Departments as $Department) : 
                     ?>
             <?php echo "<option value='$Department->id'> $Department->title </option>"; ?>        
                     <?php endforeach; ?>
                    </select>
                    </div>
                    

                         <div class="form-group">
                      <label>Due Date</label>
                            <div id="summernote"></div>
                            <input  type="date" name="due_date"  class="default" multiple>
                          </div>


                      <div class="form-group">
                      <label>Priority</label>
                      <select class="form-control" name="priority"  >
                     <option>Low</option>
                     <option>Mid</option>
                     <option>Higth</option>
                     </select>
                    </div>


          <button name="create_project" type="submit" class="btn btn-primary">Create Project</button>
        <button class="btn btn-danger">Cancel</button>



                
              </div>
            </div>

    
              </div>
         

</form>

     
            
        


</form>



              </div>
              
            </div>
          </div>
        </div>



 </div>

