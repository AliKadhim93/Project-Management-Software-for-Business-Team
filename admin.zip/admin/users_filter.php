<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">





 
  <div class="section-body">
            <div class="row">
              <div class="col-12">
                <div class="card mb-0">
                  <div class="card-body">
                    <ul class="nav nav-pills">
                      <li class="nav-item">
                        <a class="nav-link active" href="all_users.php">All <span class="badge badge-white"> <?php echo User::count_by(""); ?></span></a>
                      </li>
                     
                    </ul>
                  </div>
                </div>
              </div>
            </div>





   <div class="row mt-4">
              <div class="col-12">
                <div class="card">

                  <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_user_modal">Add User</button>
                  </div>



                  <div class="card-header">
                  <h4>All Users Table</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">




                      <form action="" method="post">
                      <table class="table table-striped">

   
// this script provides essential user management features,
// allowing administrators to view, add, edit, and delete users from the system. //
It also includes basic authentication and permission checks to ensure that only authorized users can access the admin panel functionalities.







   <?php 

if(!empty($_GET['by'])){
  $by= $_GET['by'];
     $Users= User::final_all_by($by);
     } ?>
    

                        
                          <th>#</th>
                          <th>ID</th>
                          <th>Username</th>
                          <th>Picture</th>
                          <th>Firstname</th>
                          <th>Lastname</th>
                          <th>Status</th>
                          <th>Roles</th>
                          <th>Action</th>
                        </tr>
  <?php $i=1 ?>
                          <?php   foreach ($Users as $User) : ?>

                        <tr>



                          <td><?php echo $i."-"; $i+=1; ?></td>
                          <td><?php echo $User->id; ?></td>
                          <td><?php echo $User->username; ?></td>

                          <td>
                            <img alt="image" src="assets/img/users/<?php echo $User->img; ?>" class="rounded-circle" width="35"
                              data-toggle="tooltip" title="<?php echo $User->username; ?>">
                          </td>
                         
                          <td><?php echo $User->fname; ?></td>
                          <td><?php echo $User->lname; ?></td>


                        <td><?php echo $User->status; ?></td>


                          <td>
                            <div class="badge badge-success"><?php echo $User->user_roles; ?></div>
                          </td>


                  <td>
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_user.php?id=<?php echo $User->id; ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_User.php?id=<?php echo $User->id; ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>


                        </tr>
                           <?php endforeach; ?>
                    </table>
                    </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>


   



      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
