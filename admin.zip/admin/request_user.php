<?php require_once("admin_includes/admin_header.php"); ?>

<?php  
//rsepansbal for exceept to inter dashbord

if(empty($_GET['id'])){
    redirect("index.php");
}

$user = User::find_by_id($_GET['id']);


if($user){
 $user->access = "enable";
        $user->save();
redirect("index.php");
$session->message("Username :  ". $user->username ." can access now to Dashboard");



}






 ?>
