

<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>



//edit post





<?php 


if(empty($_GET['id'])){
    redirect("posts.php");
}

$posts = Posts::find_by_id($_GET['id']);


 ?>  






<?php  
$activity = new Activity();


if(isset($_POST['update_post'])){


if($posts){
 $posts->post_title = $_POST['post_title'];
 $posts->post_author = $_POST['post_author'];
 $posts->assigh_date = date('d-m-y');
 $posts->post_content = $_POST['post_content'];
 $posts->post_department_id = $_POST['post_department_id'];
 $posts->post_status = $_POST['post_status'];
 $posts->post_author_id = $_SESSION['user_id'];






if(empty($_FILES['post_image'])){




$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update Post ID: ".  $posts->id . " ";
$activity->action_id = $posts->id; 
$activity->action_name = "update";
$activity->save();




    $posts->save();
    redirect("posts.php");
     $session->message("Posts has been added successfully");
}else{

$posts->set_file($_FILES['post_image']);
$posts->save_user_and_image();

$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update Post ID: ".  $posts->id . " ";
$activity->action_id = $posts->id; 
$activity->action_name = "update";
$activity->save();


$posts->save();

redirect("posts.php");
 $session->message("Posts has been added successfully");
}

}}


 ?>




      <!-- Main Content -->
      <div class="main-content">
        <section class="section">



            <div class="row">
              <div class="col-12">
                <div class="card">
                  <div class="card-header">
                    <h4>Write Your Post</h4>
                  </div>
                  <div class="card-body">
                    
                    

                    <form action=""  method="post" enctype="multipart/form-data" >


                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Title</label>
                      <div class="col-sm-12 col-md-7">
                        <input name="post_title" type="text" class="form-control" value="<?php echo $posts->post_title ;?>" >
                      </div>
                    </div>





   



                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Departments</label>
                      <div class="col-sm-12 col-md-7">
                          <select class="form-control selectric" name="post_department_id"  >
                <?php $Departments= Department::find_all();
            foreach ($Departments as $Department) : 
                     ?>
             <?php echo "<option value='$Department->id'> $Department->title </option>"; ?>        
                     <?php endforeach; ?>
                    </select>
                      </div>
                    </div>


<div class="form-group row mb-4">
<label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Content</label>
<div class="col-sm-12 col-md-7">
<textarea
name="post_content" class="form-control summernote-simple"> <?php echo $posts->post_content; ?></textarea>
</div>
</div>

     
                                     
               
                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Thumbnail</label>
                      <div class="col-sm-12 col-md-7">
                        <div id="image-preview" class="image-preview">
                          <label for="image-upload" id="image-label">Choose File</label>
                          <input type="file" name="post_image" id="image-upload" />
                        </div>
                      </div>
                    </div>




                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3">Status</label>
                      <div class="col-sm-12 col-md-7">
                        <select name="post_status" class="form-control selectric">
                          <option>Publish</option>
                          <option>Draft</option>
                          <option>Pending</option>
                        </select>
                      </div>
                    </div>


                    <div class="form-group row mb-4">
                      <label class="col-form-label text-md-right col-12 col-md-3 col-lg-3"></label>
                      <div class="col-sm-12 col-md-7">
                        <button name="update_post" class="btn btn-primary">Update Post</button>
                      </div>
                    </div>

                     </form>

                 </div>
                </div>
              </div>
            </div>




      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
