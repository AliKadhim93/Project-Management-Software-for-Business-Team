

<?php include"admin_includes/admin_header.php"; ?>

//viwe all department and delet an adding

<?php  if(!User::is_admin($_SESSION['user_id'])){ redirect("index.php"); 
$session->message("You do not have permission to login now");
} ?>




<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">








       <div class="section-body">
            <div class="row mt-sm-4">
              <div class="col-12 col-md-12 col-lg-8">
                <div class="card author-box">

               <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_department_modal">Add Department</button>
                  </div>

          




                  <div class="card-header">
                    <h4>Departments Table</h4>
                  </div>


                  <div class="card-body">
           <table class="table table-striped">
                        <tr>
                      
                          <th>*</th>
                          <th>ID</th>
                          <th>Title</th>
                          <th>Stauts</th>
                          <th>Action</th>
                        </tr>
  <?php $Departments= Department::find_all(); ?>
  <?php $i=1 ?>
            <?php   foreach ($Departments as $Department) : ?>

                        <tr>




                       <td><?php echo $i."-";
                       $i+=1; ?></td>
                          <td><?php echo $Department->id; ?></td>
                          <td><?php echo $Department->title; ?></td>
                          <td><?php echo $Department->status; ?></td>


                   

                  <td>
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_department.php?id=<?php echo $Department->id; ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_departments.php?id=<?php echo $Department->id; ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>


                        </tr>
                           <?php endforeach; ?>
                    </table>
                             
                        </form>

                   </div>
                  </div>
                </div>
              </div>
          </div>


















      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>







<?php  

$activity = new Activity();
$department = new Department();
if(isset($_POST['add_department'])){

if($department){
$department->title = $_POST['department_name'];
$department->status  = $_POST['department_status'];

}

$department->save();

$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Add New Department ID: ".  $department->id . " ";
$activity->action_id =  $department->id;
$activity->action_name = "create";
$activity->save();

$session->message("Department has been added successfully");
redirect("departments.php");


}


 ?>
    

      <!-- ADD Depmartment modal -->
        <div class="modal fade" id="add_department_modal" tabindex="-1" role="dialog" aria-labelledby="add_department_modal"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add Dempartment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>

              <div class="modal-body">
              <div class="card-body">
            <form method="post" class="needs-validation">
              <div class="form-group">


<input name="department_name" type="text" class="form-control">
</div>



<div class="form-group">
<label>User Status</label>
<select class="form-control" name="department_status"  >
<option>Active</option>
<option>Off</option>
</select>
</div>



<div class="form-group ">
<button class="btn btn-primary" type="submit" name="add_department">Add Department</button>
</div>







</form>

              </div>
              
            </div>
          </div>
        </div>
       </div>

