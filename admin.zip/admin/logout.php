<?php require_once("admin_includes/admin_header.php"); ?>


//logout and constitutional session
<?php 

$user = User::find_by_id($_SESSION['user_id']);
if($user){
	$user->status = "Offline now";
	$user->save();
}

$session->logout();

header("Location: ../index.php");

?>