<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>





<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>




<?php  


// edit user add new activity 

$activity = new Activity();


if(empty($_GET['id'])){
    redirect("users.php");
}

$user = User::find_by_id($_GET['id']);




if(isset($_POST['update'])){


if($user){
 $user->username = $_POST['username'];
 $user->fname = $_POST['first_name'];
 $user->lname = $_POST['last_name'];
 $user->password = $_POST['password'];
 $user->user_roles = $_POST['user_roles'];

 $user->email = $_POST['user_email'];
 

if(empty($_FILES['user_image'])){
    $user->save();


$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update successfully User ID: ".  $user->id . " ";
$activity->action_id = $user->id; 
$activity->action_name = "update";
$activity->save();


redirect("all_users.php");
    $session->message("User has been Updated successfully");


}else{

$user->set_file($_FILES['user_image']);
$user->save_user_and_image();
$user->save();

$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update successfully User ID: ".  $user->id . " ";
$activity->action_id = $user->id; 
$activity->action_name = "update";
$activity->save();



redirect("all_users.php");
$session->message("User has been Updated successfully");



}




}

}


 ?>









      <!-- Main Content -->
      <div class="main-content">
        <section class="section">





<form action=""  method="post" enctype="multipart/form-data" >
            <div class="row">
              <div class="col-12 ">
                <div class="card">
                  <div class="card-header">
                    <h4>Add User</h4>
                  </div>


                  <div class="card-body">


                         <div class="form-group">
                      <label>First Name</label>
                      <input name="first_name" type="text" class="form-control" value="<?php echo $user->fname; ?>" >
                    </div>

                       <div class="form-group">
                      <label>Last Name</label>
                      <input name="last_name" type="text" class="form-control" value="<?php echo $user->lname; ?>" >
                    </div>


                    <div class="form-group">
                      <label>Username</label>
                      <input name="username" type="text" class="form-control" value="<?php echo $user->username; ?>" >
                    </div>

                    <div class="form-group">
                      <label>Password</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fas fa-lock"></i>
                          </div>
                        </div>
                        <input type="password" name="password" class="form-control pwstrength" data-indicator="pwindicator" value="<?php echo $user->password; ?>" >
                      </div>
                      <div id="pwindicator" class="pwindicator">
                        <div class="bar"></div>
                        <div class="label"></div>
                      </div>
                     </div>


               <div class="form-group">
                    <label for="user_email">User Email</label>
                    <input id="user_email" type="email" class="form-control" name="user_email" value="<?php echo $user->email; ?>">
                    <div class="invalid-feedback">
                    </div>
                  </div>


               
        

                    <div class="form-group">

                          <div> <img alt="image" src="<?php echo $user->image_path_and_placeholder(); ?>" class="rounded-circle" width="35"
                              data-toggle="tooltip" >
                              </div>
                        <label>User Image</label>
                      
       

                            <div id="summernote"></div>
                            <input  type="file" name="user_image"  class="default" multiple>
                          </div>



                      <div class="form-group">
                      <label>User roles : <?php echo $user->user_roles; ?></label>
                      <select class="form-control" name="user_roles">
              <option value="<?php echo $user->user_roles; ?>">Select</option>
                     <option>Employee</option>
                     <option>Admin</option>
                     <option>Manager</option>
                       
                      </select>
                    </div>


  


            
           

                <div class="form-group">
      <button name="update" type="submit" class="btn btn-primary">Update</button>
      <button type="button" class="btn btn-danger">Close</button>
                </div>



</div>
</div>
</div>
</div>


</form>



      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
