<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>






<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>




// eddit task


<?php  






if(empty($_GET['id'])){
    redirect("projects.php");
}
$Project = Project::find_by_id($_GET['P_id']);
$project_hr= Project_hr::find_by_id($_GET['id']);

if(isset($_POST['update'])){
if($project_hr){

 $project_hr->task_name = $_POST['task_name'];
 $project_hr->user_id = $_POST['task_user_id'];
 $project_hr->assigh_date = date('d-m-y');
 $project_hr->due_date = $_POST['due_date'];
 $project_hr->note = "empty";
  $project_hr->status = $_POST['project_status'];
$project_hr->project_id=$_GET['P_id'];

$project_hr->save();
redirect("tasks.php?id=".$_GET['P_id']);



}}

 ?>



      <!-- Main Content -->
      <div class="main-content">
        <section class="section">



<form action=""  method="post" enctype="multipart/form-data" >
            <div class="row">
              <div class="col-12 ">
                <div class="card">
                  <div class="card-header">
                    <h4>Edit Tasks Details</h4>
                  </div>
                <div class="card-body">





<label>Project Name: <?php echo $Project->project_name; ?> </label>
 


            <div class="form-group">
                      <label>Task Name</label>
                      <input name="task_name" type="text" class="form-control" value="<?php echo $project_hr->task_name; ?>">
                    </div>



             <div class="form-group">
                      <label>Project Name</label>
                      <input name="project_name" type="text" class="form-control" value="<?php echo $Project->project_name; ?>">
                    </div>

 
               <div class="form-group">
                      <label>Status</label>
                      <select class="form-control" name="project_status"  >
                     <option>In Progress</option>
                     <option>Complate</option>
                     </select>
                    </div>



             <div class="form-group">
               <label>User</label>
             <select class="form-control" name="task_user_id"  >
                <?php $user = User::find_all();
            foreach ($user as $users) : 
                     ?>
             <?php echo "<option value='$users->id'> $users->username </option>"; ?>        
                     <?php endforeach; ?>
                    </select>
                    </div>

                    

            <div class="form-group">
                      <label>Due Date</label>
                            <div id="summernote"></div>
                            <input  type="date" name="due_date"  value="<?php echo $project_hr->due_date; ?>"  class="default" multiple>
                          </div>


                  
  
        <button name="update" type="submit" class="btn btn-primary">Update Task</button>
        <button class="btn btn-danger">Cancel</button>


















</div>
</div>
</div>
</form>




      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>

