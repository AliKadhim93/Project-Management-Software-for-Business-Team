

<?php include"admin_includes/admin_header.php"; ?>







<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>


//viwe all user page


<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>


      <!-- Main Content -->
      <div class="main-content">
        <section class="section">






  <div class="section-body">
            <div class="row mt-4">
              <div class="col-12">
                <div class="card mb-0">
                  <div class="card-body">
                    <ul class="nav nav-pills">
                      <li class="nav-item">
                        <a class="nav-link active" href="all_users.php">All <span class="badge badge-white"> <?php echo User::count_by(""); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="users_filter.php?by=Admin" >Admin <span class="badge badge-primary"> <?php echo User::count_by("Admin"); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link"href="users_filter.php?by=Manager" >Managers <span class="badge badge-primary"> <?php echo User::count_by("Manager"); ?></span></a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="users_filter.php?by=Employee" >Employee <span class="badge badge-primary"><?php echo User::count_by("Employee"); ?></span></a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>







   <div class="row mt-4">
              <div class="col-12">
                <div class="card">

                  <div class="card-body">
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#add_user_modal">Add User</button>
                  </div>



                  <div class="card-header">
                  <h4>All Users Table</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                  <div class="card-body p-0">
                    <div class="table-responsive">




                      <form action="" method="post">
                      <table class="table table-striped">

   

     <?php $Users= User::find_all(); ?>


                        <tr>
                         
                          <th>#</th>
                          <th>ID</th>
                          <th>Username</th>
                          <th>Picture</th>
                          <th>Firstname</th>
                          <th>Lastname</th>
                          <th>Status</th>
                          <th>Roles</th>
                          <th>Action</th>
                        </tr>
                      <?php $i=1 ?>
                          <?php   foreach ($Users as $User) : ?>

                        <tr>



                         <td><?php echo $i."-";
                       $i+=1; ?></td>

                          <td><?php echo $User->id; ?></td>
                          <td><?php echo $User->username; ?></td>

                          <td>
                            <img alt="image" src="assets/img/users/<?php echo $User->img; ?>" class="rounded-circle" width="35"
                              data-toggle="tooltip" title="<?php echo $User->username; ?>">
                          </td>
                         
                          <td><?php echo $User->fname; ?></td>
                          <td><?php echo $User->lname; ?></td>


                        <td><?php echo $User->status; ?></td>


                          <td>
                            <div class="badge badge-success"><?php echo $User->user_roles; ?></div>
                          </td>


                  <td>
        <a class="btn btn-primary btn-action mr-1" data-toggle="tooltip" title="Edit" href="edit_user.php?id=<?php echo $User->id; ?>"><i  class="fas fa-pencil-alt"></i></a>
      
        <a onclick="javascript: return confirm('Are you sure you want to delete?');" type="submit"  href="delete_user.php?id=<?php echo $User->id; ?>" class="btn btn-danger btn-action" data-toggle="tooltip" title="Delete"><i class="fas fa-trash"></i></a>
      </td>


                        </tr>
                           <?php endforeach; ?>
                    </table>
                    </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>









      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>







<?php  

$user = new User();
$activity = new Activity();

if(isset($_POST['save_user'])){


if($user){
 $user->username = $_POST['username'];
 $user->fname = $_POST['first_name'];
 $user->lname = $_POST['last_name'];
 $user->password = md5($_POST['password']);
 $user->user_roles = $_POST['user_roles'];
 $user->status = "Offline now";
 $user->email = $_POST['user_email'];
$user->unique_id =rand(time(), 100000000);


if($user->user_exists_by($_POST['username'],$_POST['user_email'])){


echo "
<script type='text/javascript'>
      alert('User exsits try again');
    </script>          
";



}else{



if(empty($_FILES['user_image'])){
    $user->save();





    redirect("all_users.php");
$session->message("User has been added successfully");
}else{

$user->set_file($_FILES['user_image']);
$user->save_user_and_image();
$user->save();


$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Add New User ID: ".  $user->id . " ";
$activity->action_id =  $user->id;
$activity->action_name = "create";

$activity->save();
redirect("all_users.php");
$session->message("User has been added successfully");
}




}


}

}


 ?>




      <!-- basic modal -->
        <div class="modal fade" id="add_user_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
          aria-hidden="true">
          <div class="modal-dialog" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>



              <div class="modal-body">

  <div class="card-body">

<form action=""  method="post" enctype="multipart/form-data" >
   


             <div class="form-group">
                      <label>First Name</label>
                      <input name="first_name" type="text" class="form-control">
                    </div>

                       <div class="form-group">
                      <label>Last Name</label>
                      <input name="last_name" type="text" class="form-control">
                    </div>


                    <div class="form-group">
                      <label>Username</label>
                      <input name="username" type="text" class="form-control">
                    </div>

                    <div class="form-group">
                      <label>Password</label>
                      <div class="input-group">
                        <div class="input-group-prepend">
                          <div class="input-group-text">
                            <i class="fas fa-lock"></i>
                          </div>
                        </div>
                        <input type="password" name="password" class="form-control pwstrength" data-indicator="pwindicator">
                      </div>
                      <div id="pwindicator" class="pwindicator">
                        <div class="bar"></div>
                        <div class="label"></div>
                      </div>
                     </div>


               <div class="form-group">
                    <label for="user_email">User Email</label>
                    <input id="user_email" type="email" class="form-control" name="user_email">
                    <div class="invalid-feedback">
                    </div>
                  </div>

                   
        
 
                    <div class="form-group">
                      <label>User Image</label>
                            <div id="summernote"></div>
                            <input  type="file" name="user_image"  class="default" multiple>
                          </div>



                      <div class="form-group">
                      <label>User roles</label>
                      <select class="form-control" name="user_roles"  >
                     <option>Employee</option>
                     <option>Admin</option>
                     <option>Manager</option>
                       
                      </select>
                    </div>

  <div class="form-group">
    <button name="save_user" type="submit" class="btn btn-primary">Add User</button>
      <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
    </div>
   

        


</form>



              </div>
              
            </div>
          </div>
        </div>



 </div>


