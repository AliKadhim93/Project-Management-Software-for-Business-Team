<?php include"admin_includes/admin_header.php"; ?>

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>











delet post and new activite for delet post

<?php 
$activity = new Activity();

if(empty($_GET['id'])){
        header("Location: posts.php");
}


 $posts= Posts::find_by_id($_GET['id']);

if($posts){
    

$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Delete post ID: ".  $posts->id . " ";
$activity->action_id =  $_GET['id'];
$activity->action_name = "delete";

$activity->save();

$posts->delete();




        redirect("posts.php");  
        $session->message("Posts ID: ".$_GET['id']." has been Deleted successfully");
}else{
        redirect("posts.php");  
}




 ?>












<?php include"admin_includes/admin_footer.php"; ?>






