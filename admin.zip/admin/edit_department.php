<?php include"admin_includes/admin_header.php"; ?>





//

<?php  if(!$session->is_signed_in()){ header("Location: ../index.php"); } ?>

?>


<?php if($_SESSION['access'] == "enable"){  }
else{
header("Location: ../index.php");
$session->message("You do not have permission to login now");
} ?>



<?php include"admin_includes/top_nav.php"; ?>

<?php include"admin_includes/main_sidebar.php"; ?>




//edit department 


<?php 

$activity = new Activity();

if(empty($_GET['id'])){
    redirect("departments.php");
}

$department = Department::find_by_id($_GET['id']);




if(isset($_POST['update_department'])){

if($department){
$department->title = $_POST['update_name'];
$department->status  = $_POST['update_status'];


}




$activity->created_by = $_SESSION['user_id'];
$activity->date =date('d-m-y');
$activity->details = "Update Department ID: ".  $department->id . " ";
$activity->action_id = $department->id; 
$activity->action_name = "update";
$activity->save();


$department->save();
$session->message("Department has been Updated successfully");
redirect("departments.php");
}


 ?>





      <!-- Main Content -->
      <div class="main-content">
        <section class="section">




          <div class="section-body">
            <div class="row mt-sm-4">
              <div class="col-12 col-md-12 col-lg-8">
                <div class="card author-box">

                  <div class="card-header">
                    <h4>Edit Department Name</h4>
                    <div class="card-header-form">
                      <form>
                        <div class="input-group">
                          <input type="text" class="form-control" placeholder="Search">
                          <div class="input-group-btn">
                            <button class="btn btn-primary"><i class="fas fa-search"></i></button>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>


                  <div class="card-body">
                


                    <form method="post" class="needs-validation">
                        
            
                                                 
                        <div class="form-group">

                    
                      <input name="update_name" value="<?php echo  $department->title ?>" type="text" class="form-control">
                    </div>

           
        

                    <div class="form-group">
                      <label>User Status</label>
                      <select class="form-control" name="update_status"  >
                     <option>Active</option>
                     <option>Off</option>
                    </select>
                        </div>

       

                          <div class="form-group ">
                            <button class="btn btn-primary" name="update_department">Update Department</button>
                          </div>
                        </form>




    

              
                   </div>
                  </div>
                </div>
              </div>
          </div>






      

        </section>
      </div>
<?php include"admin_includes/admin_footer.php"; ?>
