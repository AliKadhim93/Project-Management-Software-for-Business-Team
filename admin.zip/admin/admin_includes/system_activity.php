<?php 

// require_once("db_object.php");


 class Activity extends Db_object {

protected static $db_table = "system_activity";

protected static $db_table_fields= array('date','created_by','details','action_id','action_name');

public $id;
public $date;
public $created_by;
public $details;
public $action_id;
public $action_name;



//This method queries the database table specified
// by static::$db_table to count the number of records where the action_name column contains the specified $action_name. 
//It returns the count of matching records.

public static function count_by_action($action_name){
    
    global $database;
    $sql = "SELECT COUNT(*) FROM ". static::$db_table ." WHERE action_name LIKE '%{$action_name}%' ";
    $result_set = $database->query($sql);

    $row = mysqli_fetch_array($result_set);

    return array_shift($row);
}




//This method facilitates retrieving activities from the database based on a specific action name.



public static function final_all_activites_by($action_name){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE action_name LIKE '%{$action_name}%' ");


}




}










?>



