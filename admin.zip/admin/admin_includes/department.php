<?php 

// require_once("db_object.php");


 class Department extends Db_object {

protected static $db_table = "departments";
protected static $db_table_fields= array('title', 'status');

public $id;
public $title;
public $status;

//class department and it three var 

 public $errors = array();
    public $upload_errors_array = array(
     UPLOAD_ERR_OK         =>"There is no error",
     UPLOAD_ERR_INI_SIZE   =>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
     UPLOAD_ERR_FORM_SIZE  =>"The uploaded file exceeds the MAZ_FILE_SIZE directive that was specified in HTML form",
     UPLOAD_ERR_PARTIAL    =>"The uploaded file was partially uploaded.",
     UPLOAD_ERR_NO_FILE    =>"No file uploaded.",
     UPLOAD_ERR_NO_TMP_DIR =>"Missing a temporary folder.",
     UPLOAD_ERR_CANT_WRITE =>"Failed to write file to disk.",
     UPLOAD_ERR_EXTENSION  =>"A php extension stopped the file upload.",
     );
    //this is passing $_FILES['uploaded_files'] as an argument








}










?>



