<?php 



 class Db_object {

protected static $db_table = "users";




//In summary, this method retrieves all records from the table 
//specified by the static::$db_table property by executing a SQL SELECT * query using the find_by_query method.







public static function find_all(){
 	global $database;
return static::find_by_query("SELECT * FROM " . static::$db_table . " ");

}




//In summary, this method retrieves a single record from the specified table by its ID,
// returning the record if found or false if no record is found.








public static function find_by_id($id){
 	global $database;
$the_result_array = static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE id= $id LIMIT 1");

return !empty($the_result_array) ? array_shift($the_result_array) : false;

}



//n summary, this method executes a given SQL query, fetches the resulting rows,
// converts each row into an object using the instantation method, and returns an array of these objects.



public static function find_by_query($sql){
global $database;
$result_set = $database->query($sql);
$the_object_array= array();
while($row = mysqli_fetch_array($result_set)){
	$the_object_array[]= static::instantation($row);
}
return $the_object_array;

}



//In summary, this method dynamically instantiates an object of the calling class,
 //iterates through the attributes of a given record,
 // and assigns values to the corresponding properties of the object if they exist. Finally, it returns the populated object.






public static function instantation($the_record){

$calling_class = get_called_class();
$the_object = new $calling_class;

foreach ($the_record as $the_attribute => $value) {
	if($the_object->has_the_attribute($the_attribute)){
		$the_object->$the_attribute= $value;
	}
}

return $the_object;

}




//In summary, this private method determines whether a given attribute exists as a property within the current object.
// It returns true if the attribute exists, and false otherwise.





private function has_the_attribute($the_attribute){
	$object_properties = get_object_vars($this);
	return array_key_exists($the_attribute,$object_properties);

}




//In summary, this method iterates through the properties of the object, 
//cleans each property value to prevent SQL injection, and returns an array containing the cleaned properties.





protected function clean_properties(){
	global $database;


	$clean_properties = array();
	foreach ($this->properties() as $key => $value) {
		$clean_properties[$key]= $database->escape_string($value);

	}
	return $clean_properties;
}




//In summary, this method iterates through the database table fields, checks 
//if the object has properties corresponding to those fields, and collects the values of those properties into an array,
// which is then returned.


protected function properties(){

$properties= array();
 foreach (static::$db_table_fields as $db_field) {

		if(property_exists($this,$db_field)){

		$properties[$db_field]= $this->$db_field;

}

 }
 return $properties;

}




//In summary, this method creates a new record in the database table associated with
// the class by constructing and executing an SQL INSERT query.
// It returns true on success and false on failure.

public function create(){
	global $database;
 $properties = $this->clean_properties();

$sql = "INSERT INTO " . static::$db_table . "(" . implode(",", array_keys($properties)) . ")";
$sql .= " VALUES ('".  implode("','", array_values($properties)) ."')";



	if($database->query($sql)){
		$this->id = $database->the_insert_id();
		return true;
	}else{
return false;
	}

}



// In summary, the save() method provides a convenient way to either update or create a record in the database,
 //depending on whether the object already exists in the database or not.

public function save(){
	return isset($this->id) ? $this->update() : $this->create();
}






//In summary, this method updates an existing record in the database with the current object's properties and returns true
 //if the update was successful, or false otherwise.


public function update(){
	global $database;
 $properties = $this->clean_properties();
$properties_pairs = array();

foreach ($properties as $key => $value) {
	$properties_pairs[] = "{$key}='$value'";
}

$sql= "UPDATE " . static::$db_table ." SET ";
$sql.= implode(",", $properties_pairs);
$sql.= " WHERE id= " . $database->escape_string($this->id);


$database->query($sql);
return (mysqli_affected_rows($database->connection) == 1) ? true : false;



}




//In summary, this method deletes an existing record from the database based on the object's ID and returns true 
//if the deletion was successful, or false otherwise.




public function delete(){
	global $database;

$sql = "DELETE FROM " . static::$db_table ." WHERE id= " . $database->escape_string($this->id);
$sql .= " LIMIT 1";
$database->query($sql);
return (mysqli_affected_rows($database->connection) == 1) ? true : false;


}





//In summary, this method retrieves the total number of records in the database table associated with the class and returns that count.

public static function count_all(){
	global $database;
	$sql = "SELECT COUNT(*) FROM ". static::$db_table;
	$result_set = $database->query($sql);

	$row = mysqli_fetch_array($result_set);

	return array_shift($row);
}





//In summary, this method retrieves the total number of records in the database table associated with
// the class that match a given user role and returns that count.



public static function count_by($user_roles){
	
	global $database;
	$sql = "SELECT COUNT(*) FROM ". static::$db_table ." WHERE user_roles LIKE '%{$user_roles}%' ";
	$result_set = $database->query($sql);

	$row = mysqli_fetch_array($result_set);

	return array_shift($row);
}
















}






?>