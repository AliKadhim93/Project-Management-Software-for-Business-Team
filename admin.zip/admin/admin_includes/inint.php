<?php 


//The script ensures that necessary files are included and constants are defined before proceeding with the application's execution.


defined('DS') ? null : define('DS', DIRECTORY_SEPARATOR);

defined('DS') ? null : define('SITE_ROOT', DS . 'Applications' . DS . 'XAMPP' . DS . 'xamppfiles' . DS . 'htdocs' . DS .'team' );

defined('INCLUDES_PATH') ? null : define('INCLUDES_PATH','SITE_ROOT' . DS . 'admin' . DS . 'includes');


require_once("config.php");
require_once("database.php");
require_once("db_object.php");
require_once("user.php");
require_once("functions.php");
require_once("session.php");
require_once("post.php");
require_once("task.php");
require_once("project.php");
require_once("department.php");
require_once("system_activity.php");

?>