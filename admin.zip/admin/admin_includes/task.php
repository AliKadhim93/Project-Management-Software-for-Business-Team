<?php 

// require_once("db_object.php");


 class Project_hr extends Db_object {

protected static $db_table = "task";
protected static $db_table_fields= array('task_name','project_id','user_id','due_date','authorities','created_by','status','priority','note','assigh_date','task_file');

public $id;
public $task_name;
public $project_id;
public $user_id;
public $due_date;
public $authorities;
public $created_by;
public $status;
public $priority;
public $note;
public $assigh_date;
public $task_file;
 public $errors = array();
    public $upload_errors_array = array(
     UPLOAD_ERR_OK         =>"There is no error",
     UPLOAD_ERR_INI_SIZE   =>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
     UPLOAD_ERR_FORM_SIZE  =>"The uploaded file exceeds the MAZ_FILE_SIZE directive that was specified in HTML form",
     UPLOAD_ERR_PARTIAL    =>"The uploaded file was partially uploaded.",
     UPLOAD_ERR_NO_FILE    =>"No file uploaded.",
     UPLOAD_ERR_NO_TMP_DIR =>"Missing a temporary folder.",
     UPLOAD_ERR_CANT_WRITE =>"Failed to write file to disk.",
     UPLOAD_ERR_EXTENSION  =>"A php extension stopped the file upload.",
     );
    //this is passing $_FILES['uploaded_files'] as an argument




//This method is likely utilized within 
//the class to obtain a structured representation of the object's properties, 
//which can be useful for various operations such as database interactions or object serialization.


protected function properties(){

$properties= array();


 foreach (self::$db_table_fields as $db_field) {

                if(property_exists($this,$db_field)){

                $properties[$db_field]= $this->$db_field;

}

 }
 return $properties;

}



//This method facilitates retrieving project users from the database based on a specific project ID.


public static function final_all_project_users($project_id){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE project_id LIKE '%{$project_id}%'" );


}



//This method facilitates retrieving records from the database associated with a specific user ID.

public static function finad_all_by($user_id){
   

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id LIKE '$user_id' ");


}



//This method facilitates retrieving records from the database associated with a specific project ID.

public static function find_all_by_project_id($id){
   
return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE project_id LIKE '$id' ");


}


//This method facilitates retrieving records from the database associated with a specific user ID.


public static function find_all_by_user_id($user_id){
   
return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id LIKE '$user_id' ");


}




}










?>



