<?php 

// require_once("db_object.php");


 class Project_hr extends Db_object {

protected static $db_table = "task";
protected static $db_table_fields= array('project_id','task_name', 'user_id', 'authorities','created_by','note','status','time','due_date' ,'priority','solutionDate','files');

public $id;
public $task_name;
public $project_id;
public $user_id;
public $authorities;
public $created_by;
public $note;
public $status;
public $time;
public $due_date;
public $priority;
public $solutionDate;
public $files;
 public $errors = array();
    public $upload_errors_array = array(
     UPLOAD_ERR_OK         =>"There is no error",
     UPLOAD_ERR_INI_SIZE   =>"The uploaded file exceeds the upload_max_filesize directive in php.ini",
     UPLOAD_ERR_FORM_SIZE  =>"The uploaded file exceeds the MAZ_FILE_SIZE directive that was specified in HTML form",
     UPLOAD_ERR_PARTIAL    =>"The uploaded file was partially uploaded.",
     UPLOAD_ERR_NO_FILE    =>"No file uploaded.",
     UPLOAD_ERR_NO_TMP_DIR =>"Missing a temporary folder.",
     UPLOAD_ERR_CANT_WRITE =>"Failed to write file to disk.",
     UPLOAD_ERR_EXTENSION  =>"A php extension stopped the file upload.",
     );
    //this is passing $_FILES['uploaded_files'] as an argument



//In summary, this method provides a way to retrieve an associative array containing the properties of the class instance, mapped to their corresponding database fields. 
//This can be useful for various operations within the class, such as database interactions.

protected function properties(){

$properties= array();


 foreach (self::$db_table_fields as $db_field) {

                if(property_exists($this,$db_field)){

                $properties[$db_field]= $this->$db_field;

}

 }
 return $properties;

}


//In summary, this method provides a way to retrieve all project users associated with a given 
//project ID by executing an SQL query with an appropriate WHERE clause.


public static function final_all_project_users($project_id){

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE project_id LIKE '%{$project_id}%'" );


}


//In summary, this method provides a way to retrieve all records from 
//the associated database table where 
//the user ID matches a specified value by executing an SQL query with an appropriate WHERE clause.


public static function finad_all_by($user_id){
   

return static::find_by_query("SELECT * FROM " . static::$db_table . " WHERE user_id LIKE '$user_id' ");


}




}










?>



