<?php ob_start(); ?>
<?php require_once("admin/admin_includes/inint.php"); ?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
  <title>CMS - Admin Dashboard </title>
  <!-- General CSS Files -->
  <link rel="stylesheet" href="admin/assets/css/app.min.css">
  <link rel="stylesheet" href="admin/assets/bundles/bootstrap-social/bootstrap-social.css">
  <!-- Template CSS -->
  <link rel="stylesheet" href="admin/assets/css/style.css">
  <link rel="stylesheet" href="admin/assets/css/components.css">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="admin/assets/css/custom.css">
  <link rel='shortcut icon' type='image/x-icon' href='admin/assets/img/favicon.ico' />
</head>

<body>


 //registration for new user and check if the user exsits or not to complate the registeration procsses 

<?php 

 if(isset($_POST['register'])){

    $user = new User();

 if($user){
 $user->username = $_POST['username'];
 $user->fname = $_POST['first_name'];
 $user->email = $_POST['user_email'];
 $user->lname = $_POST['last_name'];
 $user->password = md5($_POST['password']);
$user->img  = "user.png";
$user->created_at = date('d-m-y');
$user->access = "disable";
$user->user_roles = "Employee";
$user->unique_id =rand(time(), 100000000);
if($user->user_exists_by($_POST['username'],$_POST['user_email'])){

echo " <script type='text/javascript'> alert('User exsits try again');</script>";

}else{ 
  $user->save();
 redirect("index.php");
$session->message("Registration Successful");


}}}


 ?>
 
          

  <div class="loader"></div>
  <div id="app">
 
    <section class="section">
      <div class="container mt-5">
        <div class="row">
          <div class="col-12 col-sm-10 offset-sm-1 col-md-8 offset-md-2 col-lg-8 offset-lg-2 col-xl-8 offset-xl-2">
            <div class="card card-primary">

              <div class="card-header">
                <h4>Register</h4>
              </div>
              <div class="card-body">
                <form method="POST" method="post" enctype="multipart/form-data">

                  <div class="row">
                    <div class="form-group col-6">
                      <label for="first_name">First Name</label>
                      <input id="first_name" type="text" class="form-control" name="first_name" autofocus>
                    </div>
                    <div class="form-group col-6">
                      <label for="last_name">Last Name</label>
                      <input id="last_name" type="text" class="form-control" name="last_name">
                    </div>
                  </div>

                  <div class="form-group">
                    <label for="username">Username</label>
                    <input id="username" type="text" class="form-control" name="username">
                    <div class="invalid-feedback">
                    </div>
                  </div>

                <div class="form-group">
                    <label for="user_email">User Email</label>
                    <input id="user_email" type="email" class="form-control" name="user_email">
                    <div class="invalid-feedback">
                    </div>
                  </div>

                <div class="form-group">
                     <label for="password" class="d-block">Password</label>
                      <input id="password" type="password" class="form-control pwstrength" data-indicator="pwindicator"
                        name="password">
                    </div>
                  
                 <div class="form-group">
                    <button type="submit"  name="register" class="btn btn-primary btn-lg btn-block">
                      Register
                    </button>
                  </div>
                </form>
              </div>
                  <div class="mb-4 text-muted text-center">
                Already Registered? <a href="index.php">Login</a>
              </div>


              

            </div>

          </div>
        </div>
      </div>
    </section>
  </div>



  <!-- General JS Scripts -->
  <script src="admin/assets/js/app.min.js"></script>
  <!-- JS Libraies -->
  <!-- Page Specific JS File -->
  <!-- Template JS File -->
  <script src="admin/assets/js/scripts.js"></script>
  <!-- Custom JS File -->
  <script src="admin/assets/js/custom.js"></script>
</body>


</html>