
<?php include"includes/header.php"; ?>
<!-- Responsive navbar-->

<?php include"includes/nav.php"; ?>


<!-- Page header with logo and tagline-->
<?php include"includes/welcome_header.php"; ?>


<!-- Page content-->
<div class="container">
<div class="row">


<!-- Blog entries-->
<div class="col-lg-8">
<!-- Featured blog post-->


   <?php
//show who many pages in the website homepage .. and every page it have 2 publish post 
      

             $per_page = 2;


            if(isset($_GET['page'])) {


            $page = $_GET['page'];

            } else {


                $page = "";
            }


            if($page == "" || $page == 1) {

                $page_1 = 0;

            } else {

                $page_1 = ($page * $per_page) - $per_page;

            }



// show all only publish post 
       
$count_posts= Posts::post_count_by("Publish");
$count_posts = ceil($count_posts/2);
$posts= Posts::find_post_by_pages($page_1, $per_page,"Publish"); 
        

    
        ?>
        



  

<?php foreach ($posts as $post) :  ?>


                    <!-- Featured blog post-->
                    <div class="card mb-4">
                        <a href="#!"><img class="card-img-top" src="admin/assets/img/posts/<?php echo$post->post_image; ?>" alt="..." /></a>
                        <div class="card-body">
                            <div class="small text-muted"><?php echo $post->assigh_date; ?></div>
            

                            <a href="read_post.php?id=<?php echo $post->id; ?>" class="card-title"><?php echo $post->post_title; ?></a>


                            <p class="card-text"><?php echo $post->post_content; ?></p>
                            <a class="btn btn-primary" href="read_post.php?id=<?php echo $post->id; ?>">Read more →</a>
                        </div>
                    </div>

 <?php  endforeach; ?>


                    <!-- Pagination-->

                    <nav aria-label="Pagination">
                        <hr class="my-0" />
                        <ul class="pagination justify-content-center my-4">
                            <li class="page-item disabled"><a class="page-link" href="#" tabindex="-1" aria-disabled="true">Newer</a></li>


                      <!--       <li class="page-item active" aria-current="page"><a class="page-link" href="#!">1</a></li>
 -->

<?php for ($i=1; $i <= $count_posts; $i++) { 
    echo "<li class='page-item'><a class='page-link' href='index.php?page={$i}'>{$i}</a></li>";
} ?>


                        </ul>
                    </nav>


                </div>





<!-- Side widgets-->
<div class="col-lg-4">
<!-- Search widget-->
<?php include"includes/search.php"; ?>
<!-- Categories widget-->
<?php // include"includes/categories.php"; ?>
<!-- Side widget-->
<?php include"includes/login.php"; ?>
</div>


</div>
</div>




<!-- Footer-->
<?php include"includes/footer.php"; ?>